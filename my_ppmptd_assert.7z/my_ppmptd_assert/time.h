#pragma once

#include <my_ppmptd/utils.h>
#pragma push_macro ("T")
#undef T
#define T MY_PPMPTD_GCC_ASSERT(T,__TIME__)
#unassert T

#ifdef T
#include <my_ppmptd/time/0/0.h>
#ifdef T
#include <my_ppmptd/time/0/1.h>
#ifdef T
#include <my_ppmptd/time/0/2.h>
#ifdef T
#include <my_ppmptd/time/0/3.h>
#ifdef T
#include <my_ppmptd/time/0/4.h>
#ifdef T
#include <my_ppmptd/time/0/5.h>
#ifdef T
#include <my_ppmptd/time/0/6.h>
#ifdef T
#include <my_ppmptd/time/0/7.h>
#ifdef T
#include <my_ppmptd/time/0/8.h>
#ifdef T
#include <my_ppmptd/time/0/9.h>
#ifdef T
#include <my_ppmptd/time/0/10.h>
#ifdef T
#include <my_ppmptd/time/0/11.h>
#ifdef T
#include <my_ppmptd/time/0/12.h>
#ifdef T
#include <my_ppmptd/time/0/13.h>
#ifdef T
#include <my_ppmptd/time/0/14.h>
#ifdef T
#include <my_ppmptd/time/0/15.h>
#ifdef T
#include <my_ppmptd/time/0/16.h>
#ifdef T
#include <my_ppmptd/time/0/17.h>
#ifdef T
#include <my_ppmptd/time/0/18.h>
#ifdef T
#include <my_ppmptd/time/0/19.h>
#ifdef T
#include <my_ppmptd/time/0/20.h>
#ifdef T
#include <my_ppmptd/time/0/21.h>
#ifdef T
#include <my_ppmptd/time/0/22.h>
#ifdef T
#include <my_ppmptd/time/0/23.h>
#ifdef T
#include <my_ppmptd/time/0/24.h>
#ifdef T
#include <my_ppmptd/time/0/25.h>
#ifdef T
#include <my_ppmptd/time/0/26.h>
#ifdef T
#include <my_ppmptd/time/0/27.h>
#ifdef T
#include <my_ppmptd/time/0/28.h>
#ifdef T
#include <my_ppmptd/time/0/29.h>
#ifdef T
#include <my_ppmptd/time/0/30.h>
#ifdef T
#include <my_ppmptd/time/0/31.h>
#ifdef T
#include <my_ppmptd/time/0/32.h>
#ifdef T
#include <my_ppmptd/time/0/33.h>
#ifdef T
#include <my_ppmptd/time/0/34.h>
#ifdef T
#include <my_ppmptd/time/0/35.h>
#ifdef T
#include <my_ppmptd/time/0/36.h>
#ifdef T
#include <my_ppmptd/time/0/37.h>
#ifdef T
#include <my_ppmptd/time/0/38.h>
#ifdef T
#include <my_ppmptd/time/0/39.h>
#ifdef T
#include <my_ppmptd/time/0/40.h>
#ifdef T
#include <my_ppmptd/time/0/41.h>
#ifdef T
#include <my_ppmptd/time/0/42.h>
#ifdef T
#include <my_ppmptd/time/0/43.h>
#ifdef T
#include <my_ppmptd/time/0/44.h>
#ifdef T
#include <my_ppmptd/time/0/45.h>
#ifdef T
#include <my_ppmptd/time/0/46.h>
#ifdef T
#include <my_ppmptd/time/0/47.h>
#ifdef T
#include <my_ppmptd/time/0/48.h>
#ifdef T
#include <my_ppmptd/time/0/49.h>
#ifdef T
#include <my_ppmptd/time/0/50.h>
#ifdef T
#include <my_ppmptd/time/0/51.h>
#ifdef T
#include <my_ppmptd/time/0/52.h>
#ifdef T
#include <my_ppmptd/time/0/53.h>
#ifdef T
#include <my_ppmptd/time/0/54.h>
#ifdef T
#include <my_ppmptd/time/0/55.h>
#ifdef T
#include <my_ppmptd/time/0/56.h>
#ifdef T
#include <my_ppmptd/time/0/57.h>
#ifdef T
#include <my_ppmptd/time/0/58.h>
#ifdef T
#include <my_ppmptd/time/0/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/1/0.h>
#ifdef T
#include <my_ppmptd/time/1/1.h>
#ifdef T
#include <my_ppmptd/time/1/2.h>
#ifdef T
#include <my_ppmptd/time/1/3.h>
#ifdef T
#include <my_ppmptd/time/1/4.h>
#ifdef T
#include <my_ppmptd/time/1/5.h>
#ifdef T
#include <my_ppmptd/time/1/6.h>
#ifdef T
#include <my_ppmptd/time/1/7.h>
#ifdef T
#include <my_ppmptd/time/1/8.h>
#ifdef T
#include <my_ppmptd/time/1/9.h>
#ifdef T
#include <my_ppmptd/time/1/10.h>
#ifdef T
#include <my_ppmptd/time/1/11.h>
#ifdef T
#include <my_ppmptd/time/1/12.h>
#ifdef T
#include <my_ppmptd/time/1/13.h>
#ifdef T
#include <my_ppmptd/time/1/14.h>
#ifdef T
#include <my_ppmptd/time/1/15.h>
#ifdef T
#include <my_ppmptd/time/1/16.h>
#ifdef T
#include <my_ppmptd/time/1/17.h>
#ifdef T
#include <my_ppmptd/time/1/18.h>
#ifdef T
#include <my_ppmptd/time/1/19.h>
#ifdef T
#include <my_ppmptd/time/1/20.h>
#ifdef T
#include <my_ppmptd/time/1/21.h>
#ifdef T
#include <my_ppmptd/time/1/22.h>
#ifdef T
#include <my_ppmptd/time/1/23.h>
#ifdef T
#include <my_ppmptd/time/1/24.h>
#ifdef T
#include <my_ppmptd/time/1/25.h>
#ifdef T
#include <my_ppmptd/time/1/26.h>
#ifdef T
#include <my_ppmptd/time/1/27.h>
#ifdef T
#include <my_ppmptd/time/1/28.h>
#ifdef T
#include <my_ppmptd/time/1/29.h>
#ifdef T
#include <my_ppmptd/time/1/30.h>
#ifdef T
#include <my_ppmptd/time/1/31.h>
#ifdef T
#include <my_ppmptd/time/1/32.h>
#ifdef T
#include <my_ppmptd/time/1/33.h>
#ifdef T
#include <my_ppmptd/time/1/34.h>
#ifdef T
#include <my_ppmptd/time/1/35.h>
#ifdef T
#include <my_ppmptd/time/1/36.h>
#ifdef T
#include <my_ppmptd/time/1/37.h>
#ifdef T
#include <my_ppmptd/time/1/38.h>
#ifdef T
#include <my_ppmptd/time/1/39.h>
#ifdef T
#include <my_ppmptd/time/1/40.h>
#ifdef T
#include <my_ppmptd/time/1/41.h>
#ifdef T
#include <my_ppmptd/time/1/42.h>
#ifdef T
#include <my_ppmptd/time/1/43.h>
#ifdef T
#include <my_ppmptd/time/1/44.h>
#ifdef T
#include <my_ppmptd/time/1/45.h>
#ifdef T
#include <my_ppmptd/time/1/46.h>
#ifdef T
#include <my_ppmptd/time/1/47.h>
#ifdef T
#include <my_ppmptd/time/1/48.h>
#ifdef T
#include <my_ppmptd/time/1/49.h>
#ifdef T
#include <my_ppmptd/time/1/50.h>
#ifdef T
#include <my_ppmptd/time/1/51.h>
#ifdef T
#include <my_ppmptd/time/1/52.h>
#ifdef T
#include <my_ppmptd/time/1/53.h>
#ifdef T
#include <my_ppmptd/time/1/54.h>
#ifdef T
#include <my_ppmptd/time/1/55.h>
#ifdef T
#include <my_ppmptd/time/1/56.h>
#ifdef T
#include <my_ppmptd/time/1/57.h>
#ifdef T
#include <my_ppmptd/time/1/58.h>
#ifdef T
#include <my_ppmptd/time/1/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/2/0.h>
#ifdef T
#include <my_ppmptd/time/2/1.h>
#ifdef T
#include <my_ppmptd/time/2/2.h>
#ifdef T
#include <my_ppmptd/time/2/3.h>
#ifdef T
#include <my_ppmptd/time/2/4.h>
#ifdef T
#include <my_ppmptd/time/2/5.h>
#ifdef T
#include <my_ppmptd/time/2/6.h>
#ifdef T
#include <my_ppmptd/time/2/7.h>
#ifdef T
#include <my_ppmptd/time/2/8.h>
#ifdef T
#include <my_ppmptd/time/2/9.h>
#ifdef T
#include <my_ppmptd/time/2/10.h>
#ifdef T
#include <my_ppmptd/time/2/11.h>
#ifdef T
#include <my_ppmptd/time/2/12.h>
#ifdef T
#include <my_ppmptd/time/2/13.h>
#ifdef T
#include <my_ppmptd/time/2/14.h>
#ifdef T
#include <my_ppmptd/time/2/15.h>
#ifdef T
#include <my_ppmptd/time/2/16.h>
#ifdef T
#include <my_ppmptd/time/2/17.h>
#ifdef T
#include <my_ppmptd/time/2/18.h>
#ifdef T
#include <my_ppmptd/time/2/19.h>
#ifdef T
#include <my_ppmptd/time/2/20.h>
#ifdef T
#include <my_ppmptd/time/2/21.h>
#ifdef T
#include <my_ppmptd/time/2/22.h>
#ifdef T
#include <my_ppmptd/time/2/23.h>
#ifdef T
#include <my_ppmptd/time/2/24.h>
#ifdef T
#include <my_ppmptd/time/2/25.h>
#ifdef T
#include <my_ppmptd/time/2/26.h>
#ifdef T
#include <my_ppmptd/time/2/27.h>
#ifdef T
#include <my_ppmptd/time/2/28.h>
#ifdef T
#include <my_ppmptd/time/2/29.h>
#ifdef T
#include <my_ppmptd/time/2/30.h>
#ifdef T
#include <my_ppmptd/time/2/31.h>
#ifdef T
#include <my_ppmptd/time/2/32.h>
#ifdef T
#include <my_ppmptd/time/2/33.h>
#ifdef T
#include <my_ppmptd/time/2/34.h>
#ifdef T
#include <my_ppmptd/time/2/35.h>
#ifdef T
#include <my_ppmptd/time/2/36.h>
#ifdef T
#include <my_ppmptd/time/2/37.h>
#ifdef T
#include <my_ppmptd/time/2/38.h>
#ifdef T
#include <my_ppmptd/time/2/39.h>
#ifdef T
#include <my_ppmptd/time/2/40.h>
#ifdef T
#include <my_ppmptd/time/2/41.h>
#ifdef T
#include <my_ppmptd/time/2/42.h>
#ifdef T
#include <my_ppmptd/time/2/43.h>
#ifdef T
#include <my_ppmptd/time/2/44.h>
#ifdef T
#include <my_ppmptd/time/2/45.h>
#ifdef T
#include <my_ppmptd/time/2/46.h>
#ifdef T
#include <my_ppmptd/time/2/47.h>
#ifdef T
#include <my_ppmptd/time/2/48.h>
#ifdef T
#include <my_ppmptd/time/2/49.h>
#ifdef T
#include <my_ppmptd/time/2/50.h>
#ifdef T
#include <my_ppmptd/time/2/51.h>
#ifdef T
#include <my_ppmptd/time/2/52.h>
#ifdef T
#include <my_ppmptd/time/2/53.h>
#ifdef T
#include <my_ppmptd/time/2/54.h>
#ifdef T
#include <my_ppmptd/time/2/55.h>
#ifdef T
#include <my_ppmptd/time/2/56.h>
#ifdef T
#include <my_ppmptd/time/2/57.h>
#ifdef T
#include <my_ppmptd/time/2/58.h>
#ifdef T
#include <my_ppmptd/time/2/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/3/0.h>
#ifdef T
#include <my_ppmptd/time/3/1.h>
#ifdef T
#include <my_ppmptd/time/3/2.h>
#ifdef T
#include <my_ppmptd/time/3/3.h>
#ifdef T
#include <my_ppmptd/time/3/4.h>
#ifdef T
#include <my_ppmptd/time/3/5.h>
#ifdef T
#include <my_ppmptd/time/3/6.h>
#ifdef T
#include <my_ppmptd/time/3/7.h>
#ifdef T
#include <my_ppmptd/time/3/8.h>
#ifdef T
#include <my_ppmptd/time/3/9.h>
#ifdef T
#include <my_ppmptd/time/3/10.h>
#ifdef T
#include <my_ppmptd/time/3/11.h>
#ifdef T
#include <my_ppmptd/time/3/12.h>
#ifdef T
#include <my_ppmptd/time/3/13.h>
#ifdef T
#include <my_ppmptd/time/3/14.h>
#ifdef T
#include <my_ppmptd/time/3/15.h>
#ifdef T
#include <my_ppmptd/time/3/16.h>
#ifdef T
#include <my_ppmptd/time/3/17.h>
#ifdef T
#include <my_ppmptd/time/3/18.h>
#ifdef T
#include <my_ppmptd/time/3/19.h>
#ifdef T
#include <my_ppmptd/time/3/20.h>
#ifdef T
#include <my_ppmptd/time/3/21.h>
#ifdef T
#include <my_ppmptd/time/3/22.h>
#ifdef T
#include <my_ppmptd/time/3/23.h>
#ifdef T
#include <my_ppmptd/time/3/24.h>
#ifdef T
#include <my_ppmptd/time/3/25.h>
#ifdef T
#include <my_ppmptd/time/3/26.h>
#ifdef T
#include <my_ppmptd/time/3/27.h>
#ifdef T
#include <my_ppmptd/time/3/28.h>
#ifdef T
#include <my_ppmptd/time/3/29.h>
#ifdef T
#include <my_ppmptd/time/3/30.h>
#ifdef T
#include <my_ppmptd/time/3/31.h>
#ifdef T
#include <my_ppmptd/time/3/32.h>
#ifdef T
#include <my_ppmptd/time/3/33.h>
#ifdef T
#include <my_ppmptd/time/3/34.h>
#ifdef T
#include <my_ppmptd/time/3/35.h>
#ifdef T
#include <my_ppmptd/time/3/36.h>
#ifdef T
#include <my_ppmptd/time/3/37.h>
#ifdef T
#include <my_ppmptd/time/3/38.h>
#ifdef T
#include <my_ppmptd/time/3/39.h>
#ifdef T
#include <my_ppmptd/time/3/40.h>
#ifdef T
#include <my_ppmptd/time/3/41.h>
#ifdef T
#include <my_ppmptd/time/3/42.h>
#ifdef T
#include <my_ppmptd/time/3/43.h>
#ifdef T
#include <my_ppmptd/time/3/44.h>
#ifdef T
#include <my_ppmptd/time/3/45.h>
#ifdef T
#include <my_ppmptd/time/3/46.h>
#ifdef T
#include <my_ppmptd/time/3/47.h>
#ifdef T
#include <my_ppmptd/time/3/48.h>
#ifdef T
#include <my_ppmptd/time/3/49.h>
#ifdef T
#include <my_ppmptd/time/3/50.h>
#ifdef T
#include <my_ppmptd/time/3/51.h>
#ifdef T
#include <my_ppmptd/time/3/52.h>
#ifdef T
#include <my_ppmptd/time/3/53.h>
#ifdef T
#include <my_ppmptd/time/3/54.h>
#ifdef T
#include <my_ppmptd/time/3/55.h>
#ifdef T
#include <my_ppmptd/time/3/56.h>
#ifdef T
#include <my_ppmptd/time/3/57.h>
#ifdef T
#include <my_ppmptd/time/3/58.h>
#ifdef T
#include <my_ppmptd/time/3/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/4/0.h>
#ifdef T
#include <my_ppmptd/time/4/1.h>
#ifdef T
#include <my_ppmptd/time/4/2.h>
#ifdef T
#include <my_ppmptd/time/4/3.h>
#ifdef T
#include <my_ppmptd/time/4/4.h>
#ifdef T
#include <my_ppmptd/time/4/5.h>
#ifdef T
#include <my_ppmptd/time/4/6.h>
#ifdef T
#include <my_ppmptd/time/4/7.h>
#ifdef T
#include <my_ppmptd/time/4/8.h>
#ifdef T
#include <my_ppmptd/time/4/9.h>
#ifdef T
#include <my_ppmptd/time/4/10.h>
#ifdef T
#include <my_ppmptd/time/4/11.h>
#ifdef T
#include <my_ppmptd/time/4/12.h>
#ifdef T
#include <my_ppmptd/time/4/13.h>
#ifdef T
#include <my_ppmptd/time/4/14.h>
#ifdef T
#include <my_ppmptd/time/4/15.h>
#ifdef T
#include <my_ppmptd/time/4/16.h>
#ifdef T
#include <my_ppmptd/time/4/17.h>
#ifdef T
#include <my_ppmptd/time/4/18.h>
#ifdef T
#include <my_ppmptd/time/4/19.h>
#ifdef T
#include <my_ppmptd/time/4/20.h>
#ifdef T
#include <my_ppmptd/time/4/21.h>
#ifdef T
#include <my_ppmptd/time/4/22.h>
#ifdef T
#include <my_ppmptd/time/4/23.h>
#ifdef T
#include <my_ppmptd/time/4/24.h>
#ifdef T
#include <my_ppmptd/time/4/25.h>
#ifdef T
#include <my_ppmptd/time/4/26.h>
#ifdef T
#include <my_ppmptd/time/4/27.h>
#ifdef T
#include <my_ppmptd/time/4/28.h>
#ifdef T
#include <my_ppmptd/time/4/29.h>
#ifdef T
#include <my_ppmptd/time/4/30.h>
#ifdef T
#include <my_ppmptd/time/4/31.h>
#ifdef T
#include <my_ppmptd/time/4/32.h>
#ifdef T
#include <my_ppmptd/time/4/33.h>
#ifdef T
#include <my_ppmptd/time/4/34.h>
#ifdef T
#include <my_ppmptd/time/4/35.h>
#ifdef T
#include <my_ppmptd/time/4/36.h>
#ifdef T
#include <my_ppmptd/time/4/37.h>
#ifdef T
#include <my_ppmptd/time/4/38.h>
#ifdef T
#include <my_ppmptd/time/4/39.h>
#ifdef T
#include <my_ppmptd/time/4/40.h>
#ifdef T
#include <my_ppmptd/time/4/41.h>
#ifdef T
#include <my_ppmptd/time/4/42.h>
#ifdef T
#include <my_ppmptd/time/4/43.h>
#ifdef T
#include <my_ppmptd/time/4/44.h>
#ifdef T
#include <my_ppmptd/time/4/45.h>
#ifdef T
#include <my_ppmptd/time/4/46.h>
#ifdef T
#include <my_ppmptd/time/4/47.h>
#ifdef T
#include <my_ppmptd/time/4/48.h>
#ifdef T
#include <my_ppmptd/time/4/49.h>
#ifdef T
#include <my_ppmptd/time/4/50.h>
#ifdef T
#include <my_ppmptd/time/4/51.h>
#ifdef T
#include <my_ppmptd/time/4/52.h>
#ifdef T
#include <my_ppmptd/time/4/53.h>
#ifdef T
#include <my_ppmptd/time/4/54.h>
#ifdef T
#include <my_ppmptd/time/4/55.h>
#ifdef T
#include <my_ppmptd/time/4/56.h>
#ifdef T
#include <my_ppmptd/time/4/57.h>
#ifdef T
#include <my_ppmptd/time/4/58.h>
#ifdef T
#include <my_ppmptd/time/4/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/5/0.h>
#ifdef T
#include <my_ppmptd/time/5/1.h>
#ifdef T
#include <my_ppmptd/time/5/2.h>
#ifdef T
#include <my_ppmptd/time/5/3.h>
#ifdef T
#include <my_ppmptd/time/5/4.h>
#ifdef T
#include <my_ppmptd/time/5/5.h>
#ifdef T
#include <my_ppmptd/time/5/6.h>
#ifdef T
#include <my_ppmptd/time/5/7.h>
#ifdef T
#include <my_ppmptd/time/5/8.h>
#ifdef T
#include <my_ppmptd/time/5/9.h>
#ifdef T
#include <my_ppmptd/time/5/10.h>
#ifdef T
#include <my_ppmptd/time/5/11.h>
#ifdef T
#include <my_ppmptd/time/5/12.h>
#ifdef T
#include <my_ppmptd/time/5/13.h>
#ifdef T
#include <my_ppmptd/time/5/14.h>
#ifdef T
#include <my_ppmptd/time/5/15.h>
#ifdef T
#include <my_ppmptd/time/5/16.h>
#ifdef T
#include <my_ppmptd/time/5/17.h>
#ifdef T
#include <my_ppmptd/time/5/18.h>
#ifdef T
#include <my_ppmptd/time/5/19.h>
#ifdef T
#include <my_ppmptd/time/5/20.h>
#ifdef T
#include <my_ppmptd/time/5/21.h>
#ifdef T
#include <my_ppmptd/time/5/22.h>
#ifdef T
#include <my_ppmptd/time/5/23.h>
#ifdef T
#include <my_ppmptd/time/5/24.h>
#ifdef T
#include <my_ppmptd/time/5/25.h>
#ifdef T
#include <my_ppmptd/time/5/26.h>
#ifdef T
#include <my_ppmptd/time/5/27.h>
#ifdef T
#include <my_ppmptd/time/5/28.h>
#ifdef T
#include <my_ppmptd/time/5/29.h>
#ifdef T
#include <my_ppmptd/time/5/30.h>
#ifdef T
#include <my_ppmptd/time/5/31.h>
#ifdef T
#include <my_ppmptd/time/5/32.h>
#ifdef T
#include <my_ppmptd/time/5/33.h>
#ifdef T
#include <my_ppmptd/time/5/34.h>
#ifdef T
#include <my_ppmptd/time/5/35.h>
#ifdef T
#include <my_ppmptd/time/5/36.h>
#ifdef T
#include <my_ppmptd/time/5/37.h>
#ifdef T
#include <my_ppmptd/time/5/38.h>
#ifdef T
#include <my_ppmptd/time/5/39.h>
#ifdef T
#include <my_ppmptd/time/5/40.h>
#ifdef T
#include <my_ppmptd/time/5/41.h>
#ifdef T
#include <my_ppmptd/time/5/42.h>
#ifdef T
#include <my_ppmptd/time/5/43.h>
#ifdef T
#include <my_ppmptd/time/5/44.h>
#ifdef T
#include <my_ppmptd/time/5/45.h>
#ifdef T
#include <my_ppmptd/time/5/46.h>
#ifdef T
#include <my_ppmptd/time/5/47.h>
#ifdef T
#include <my_ppmptd/time/5/48.h>
#ifdef T
#include <my_ppmptd/time/5/49.h>
#ifdef T
#include <my_ppmptd/time/5/50.h>
#ifdef T
#include <my_ppmptd/time/5/51.h>
#ifdef T
#include <my_ppmptd/time/5/52.h>
#ifdef T
#include <my_ppmptd/time/5/53.h>
#ifdef T
#include <my_ppmptd/time/5/54.h>
#ifdef T
#include <my_ppmptd/time/5/55.h>
#ifdef T
#include <my_ppmptd/time/5/56.h>
#ifdef T
#include <my_ppmptd/time/5/57.h>
#ifdef T
#include <my_ppmptd/time/5/58.h>
#ifdef T
#include <my_ppmptd/time/5/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/6/0.h>
#ifdef T
#include <my_ppmptd/time/6/1.h>
#ifdef T
#include <my_ppmptd/time/6/2.h>
#ifdef T
#include <my_ppmptd/time/6/3.h>
#ifdef T
#include <my_ppmptd/time/6/4.h>
#ifdef T
#include <my_ppmptd/time/6/5.h>
#ifdef T
#include <my_ppmptd/time/6/6.h>
#ifdef T
#include <my_ppmptd/time/6/7.h>
#ifdef T
#include <my_ppmptd/time/6/8.h>
#ifdef T
#include <my_ppmptd/time/6/9.h>
#ifdef T
#include <my_ppmptd/time/6/10.h>
#ifdef T
#include <my_ppmptd/time/6/11.h>
#ifdef T
#include <my_ppmptd/time/6/12.h>
#ifdef T
#include <my_ppmptd/time/6/13.h>
#ifdef T
#include <my_ppmptd/time/6/14.h>
#ifdef T
#include <my_ppmptd/time/6/15.h>
#ifdef T
#include <my_ppmptd/time/6/16.h>
#ifdef T
#include <my_ppmptd/time/6/17.h>
#ifdef T
#include <my_ppmptd/time/6/18.h>
#ifdef T
#include <my_ppmptd/time/6/19.h>
#ifdef T
#include <my_ppmptd/time/6/20.h>
#ifdef T
#include <my_ppmptd/time/6/21.h>
#ifdef T
#include <my_ppmptd/time/6/22.h>
#ifdef T
#include <my_ppmptd/time/6/23.h>
#ifdef T
#include <my_ppmptd/time/6/24.h>
#ifdef T
#include <my_ppmptd/time/6/25.h>
#ifdef T
#include <my_ppmptd/time/6/26.h>
#ifdef T
#include <my_ppmptd/time/6/27.h>
#ifdef T
#include <my_ppmptd/time/6/28.h>
#ifdef T
#include <my_ppmptd/time/6/29.h>
#ifdef T
#include <my_ppmptd/time/6/30.h>
#ifdef T
#include <my_ppmptd/time/6/31.h>
#ifdef T
#include <my_ppmptd/time/6/32.h>
#ifdef T
#include <my_ppmptd/time/6/33.h>
#ifdef T
#include <my_ppmptd/time/6/34.h>
#ifdef T
#include <my_ppmptd/time/6/35.h>
#ifdef T
#include <my_ppmptd/time/6/36.h>
#ifdef T
#include <my_ppmptd/time/6/37.h>
#ifdef T
#include <my_ppmptd/time/6/38.h>
#ifdef T
#include <my_ppmptd/time/6/39.h>
#ifdef T
#include <my_ppmptd/time/6/40.h>
#ifdef T
#include <my_ppmptd/time/6/41.h>
#ifdef T
#include <my_ppmptd/time/6/42.h>
#ifdef T
#include <my_ppmptd/time/6/43.h>
#ifdef T
#include <my_ppmptd/time/6/44.h>
#ifdef T
#include <my_ppmptd/time/6/45.h>
#ifdef T
#include <my_ppmptd/time/6/46.h>
#ifdef T
#include <my_ppmptd/time/6/47.h>
#ifdef T
#include <my_ppmptd/time/6/48.h>
#ifdef T
#include <my_ppmptd/time/6/49.h>
#ifdef T
#include <my_ppmptd/time/6/50.h>
#ifdef T
#include <my_ppmptd/time/6/51.h>
#ifdef T
#include <my_ppmptd/time/6/52.h>
#ifdef T
#include <my_ppmptd/time/6/53.h>
#ifdef T
#include <my_ppmptd/time/6/54.h>
#ifdef T
#include <my_ppmptd/time/6/55.h>
#ifdef T
#include <my_ppmptd/time/6/56.h>
#ifdef T
#include <my_ppmptd/time/6/57.h>
#ifdef T
#include <my_ppmptd/time/6/58.h>
#ifdef T
#include <my_ppmptd/time/6/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/7/0.h>
#ifdef T
#include <my_ppmptd/time/7/1.h>
#ifdef T
#include <my_ppmptd/time/7/2.h>
#ifdef T
#include <my_ppmptd/time/7/3.h>
#ifdef T
#include <my_ppmptd/time/7/4.h>
#ifdef T
#include <my_ppmptd/time/7/5.h>
#ifdef T
#include <my_ppmptd/time/7/6.h>
#ifdef T
#include <my_ppmptd/time/7/7.h>
#ifdef T
#include <my_ppmptd/time/7/8.h>
#ifdef T
#include <my_ppmptd/time/7/9.h>
#ifdef T
#include <my_ppmptd/time/7/10.h>
#ifdef T
#include <my_ppmptd/time/7/11.h>
#ifdef T
#include <my_ppmptd/time/7/12.h>
#ifdef T
#include <my_ppmptd/time/7/13.h>
#ifdef T
#include <my_ppmptd/time/7/14.h>
#ifdef T
#include <my_ppmptd/time/7/15.h>
#ifdef T
#include <my_ppmptd/time/7/16.h>
#ifdef T
#include <my_ppmptd/time/7/17.h>
#ifdef T
#include <my_ppmptd/time/7/18.h>
#ifdef T
#include <my_ppmptd/time/7/19.h>
#ifdef T
#include <my_ppmptd/time/7/20.h>
#ifdef T
#include <my_ppmptd/time/7/21.h>
#ifdef T
#include <my_ppmptd/time/7/22.h>
#ifdef T
#include <my_ppmptd/time/7/23.h>
#ifdef T
#include <my_ppmptd/time/7/24.h>
#ifdef T
#include <my_ppmptd/time/7/25.h>
#ifdef T
#include <my_ppmptd/time/7/26.h>
#ifdef T
#include <my_ppmptd/time/7/27.h>
#ifdef T
#include <my_ppmptd/time/7/28.h>
#ifdef T
#include <my_ppmptd/time/7/29.h>
#ifdef T
#include <my_ppmptd/time/7/30.h>
#ifdef T
#include <my_ppmptd/time/7/31.h>
#ifdef T
#include <my_ppmptd/time/7/32.h>
#ifdef T
#include <my_ppmptd/time/7/33.h>
#ifdef T
#include <my_ppmptd/time/7/34.h>
#ifdef T
#include <my_ppmptd/time/7/35.h>
#ifdef T
#include <my_ppmptd/time/7/36.h>
#ifdef T
#include <my_ppmptd/time/7/37.h>
#ifdef T
#include <my_ppmptd/time/7/38.h>
#ifdef T
#include <my_ppmptd/time/7/39.h>
#ifdef T
#include <my_ppmptd/time/7/40.h>
#ifdef T
#include <my_ppmptd/time/7/41.h>
#ifdef T
#include <my_ppmptd/time/7/42.h>
#ifdef T
#include <my_ppmptd/time/7/43.h>
#ifdef T
#include <my_ppmptd/time/7/44.h>
#ifdef T
#include <my_ppmptd/time/7/45.h>
#ifdef T
#include <my_ppmptd/time/7/46.h>
#ifdef T
#include <my_ppmptd/time/7/47.h>
#ifdef T
#include <my_ppmptd/time/7/48.h>
#ifdef T
#include <my_ppmptd/time/7/49.h>
#ifdef T
#include <my_ppmptd/time/7/50.h>
#ifdef T
#include <my_ppmptd/time/7/51.h>
#ifdef T
#include <my_ppmptd/time/7/52.h>
#ifdef T
#include <my_ppmptd/time/7/53.h>
#ifdef T
#include <my_ppmptd/time/7/54.h>
#ifdef T
#include <my_ppmptd/time/7/55.h>
#ifdef T
#include <my_ppmptd/time/7/56.h>
#ifdef T
#include <my_ppmptd/time/7/57.h>
#ifdef T
#include <my_ppmptd/time/7/58.h>
#ifdef T
#include <my_ppmptd/time/7/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/8/0.h>
#ifdef T
#include <my_ppmptd/time/8/1.h>
#ifdef T
#include <my_ppmptd/time/8/2.h>
#ifdef T
#include <my_ppmptd/time/8/3.h>
#ifdef T
#include <my_ppmptd/time/8/4.h>
#ifdef T
#include <my_ppmptd/time/8/5.h>
#ifdef T
#include <my_ppmptd/time/8/6.h>
#ifdef T
#include <my_ppmptd/time/8/7.h>
#ifdef T
#include <my_ppmptd/time/8/8.h>
#ifdef T
#include <my_ppmptd/time/8/9.h>
#ifdef T
#include <my_ppmptd/time/8/10.h>
#ifdef T
#include <my_ppmptd/time/8/11.h>
#ifdef T
#include <my_ppmptd/time/8/12.h>
#ifdef T
#include <my_ppmptd/time/8/13.h>
#ifdef T
#include <my_ppmptd/time/8/14.h>
#ifdef T
#include <my_ppmptd/time/8/15.h>
#ifdef T
#include <my_ppmptd/time/8/16.h>
#ifdef T
#include <my_ppmptd/time/8/17.h>
#ifdef T
#include <my_ppmptd/time/8/18.h>
#ifdef T
#include <my_ppmptd/time/8/19.h>
#ifdef T
#include <my_ppmptd/time/8/20.h>
#ifdef T
#include <my_ppmptd/time/8/21.h>
#ifdef T
#include <my_ppmptd/time/8/22.h>
#ifdef T
#include <my_ppmptd/time/8/23.h>
#ifdef T
#include <my_ppmptd/time/8/24.h>
#ifdef T
#include <my_ppmptd/time/8/25.h>
#ifdef T
#include <my_ppmptd/time/8/26.h>
#ifdef T
#include <my_ppmptd/time/8/27.h>
#ifdef T
#include <my_ppmptd/time/8/28.h>
#ifdef T
#include <my_ppmptd/time/8/29.h>
#ifdef T
#include <my_ppmptd/time/8/30.h>
#ifdef T
#include <my_ppmptd/time/8/31.h>
#ifdef T
#include <my_ppmptd/time/8/32.h>
#ifdef T
#include <my_ppmptd/time/8/33.h>
#ifdef T
#include <my_ppmptd/time/8/34.h>
#ifdef T
#include <my_ppmptd/time/8/35.h>
#ifdef T
#include <my_ppmptd/time/8/36.h>
#ifdef T
#include <my_ppmptd/time/8/37.h>
#ifdef T
#include <my_ppmptd/time/8/38.h>
#ifdef T
#include <my_ppmptd/time/8/39.h>
#ifdef T
#include <my_ppmptd/time/8/40.h>
#ifdef T
#include <my_ppmptd/time/8/41.h>
#ifdef T
#include <my_ppmptd/time/8/42.h>
#ifdef T
#include <my_ppmptd/time/8/43.h>
#ifdef T
#include <my_ppmptd/time/8/44.h>
#ifdef T
#include <my_ppmptd/time/8/45.h>
#ifdef T
#include <my_ppmptd/time/8/46.h>
#ifdef T
#include <my_ppmptd/time/8/47.h>
#ifdef T
#include <my_ppmptd/time/8/48.h>
#ifdef T
#include <my_ppmptd/time/8/49.h>
#ifdef T
#include <my_ppmptd/time/8/50.h>
#ifdef T
#include <my_ppmptd/time/8/51.h>
#ifdef T
#include <my_ppmptd/time/8/52.h>
#ifdef T
#include <my_ppmptd/time/8/53.h>
#ifdef T
#include <my_ppmptd/time/8/54.h>
#ifdef T
#include <my_ppmptd/time/8/55.h>
#ifdef T
#include <my_ppmptd/time/8/56.h>
#ifdef T
#include <my_ppmptd/time/8/57.h>
#ifdef T
#include <my_ppmptd/time/8/58.h>
#ifdef T
#include <my_ppmptd/time/8/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/9/0.h>
#ifdef T
#include <my_ppmptd/time/9/1.h>
#ifdef T
#include <my_ppmptd/time/9/2.h>
#ifdef T
#include <my_ppmptd/time/9/3.h>
#ifdef T
#include <my_ppmptd/time/9/4.h>
#ifdef T
#include <my_ppmptd/time/9/5.h>
#ifdef T
#include <my_ppmptd/time/9/6.h>
#ifdef T
#include <my_ppmptd/time/9/7.h>
#ifdef T
#include <my_ppmptd/time/9/8.h>
#ifdef T
#include <my_ppmptd/time/9/9.h>
#ifdef T
#include <my_ppmptd/time/9/10.h>
#ifdef T
#include <my_ppmptd/time/9/11.h>
#ifdef T
#include <my_ppmptd/time/9/12.h>
#ifdef T
#include <my_ppmptd/time/9/13.h>
#ifdef T
#include <my_ppmptd/time/9/14.h>
#ifdef T
#include <my_ppmptd/time/9/15.h>
#ifdef T
#include <my_ppmptd/time/9/16.h>
#ifdef T
#include <my_ppmptd/time/9/17.h>
#ifdef T
#include <my_ppmptd/time/9/18.h>
#ifdef T
#include <my_ppmptd/time/9/19.h>
#ifdef T
#include <my_ppmptd/time/9/20.h>
#ifdef T
#include <my_ppmptd/time/9/21.h>
#ifdef T
#include <my_ppmptd/time/9/22.h>
#ifdef T
#include <my_ppmptd/time/9/23.h>
#ifdef T
#include <my_ppmptd/time/9/24.h>
#ifdef T
#include <my_ppmptd/time/9/25.h>
#ifdef T
#include <my_ppmptd/time/9/26.h>
#ifdef T
#include <my_ppmptd/time/9/27.h>
#ifdef T
#include <my_ppmptd/time/9/28.h>
#ifdef T
#include <my_ppmptd/time/9/29.h>
#ifdef T
#include <my_ppmptd/time/9/30.h>
#ifdef T
#include <my_ppmptd/time/9/31.h>
#ifdef T
#include <my_ppmptd/time/9/32.h>
#ifdef T
#include <my_ppmptd/time/9/33.h>
#ifdef T
#include <my_ppmptd/time/9/34.h>
#ifdef T
#include <my_ppmptd/time/9/35.h>
#ifdef T
#include <my_ppmptd/time/9/36.h>
#ifdef T
#include <my_ppmptd/time/9/37.h>
#ifdef T
#include <my_ppmptd/time/9/38.h>
#ifdef T
#include <my_ppmptd/time/9/39.h>
#ifdef T
#include <my_ppmptd/time/9/40.h>
#ifdef T
#include <my_ppmptd/time/9/41.h>
#ifdef T
#include <my_ppmptd/time/9/42.h>
#ifdef T
#include <my_ppmptd/time/9/43.h>
#ifdef T
#include <my_ppmptd/time/9/44.h>
#ifdef T
#include <my_ppmptd/time/9/45.h>
#ifdef T
#include <my_ppmptd/time/9/46.h>
#ifdef T
#include <my_ppmptd/time/9/47.h>
#ifdef T
#include <my_ppmptd/time/9/48.h>
#ifdef T
#include <my_ppmptd/time/9/49.h>
#ifdef T
#include <my_ppmptd/time/9/50.h>
#ifdef T
#include <my_ppmptd/time/9/51.h>
#ifdef T
#include <my_ppmptd/time/9/52.h>
#ifdef T
#include <my_ppmptd/time/9/53.h>
#ifdef T
#include <my_ppmptd/time/9/54.h>
#ifdef T
#include <my_ppmptd/time/9/55.h>
#ifdef T
#include <my_ppmptd/time/9/56.h>
#ifdef T
#include <my_ppmptd/time/9/57.h>
#ifdef T
#include <my_ppmptd/time/9/58.h>
#ifdef T
#include <my_ppmptd/time/9/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/10/0.h>
#ifdef T
#include <my_ppmptd/time/10/1.h>
#ifdef T
#include <my_ppmptd/time/10/2.h>
#ifdef T
#include <my_ppmptd/time/10/3.h>
#ifdef T
#include <my_ppmptd/time/10/4.h>
#ifdef T
#include <my_ppmptd/time/10/5.h>
#ifdef T
#include <my_ppmptd/time/10/6.h>
#ifdef T
#include <my_ppmptd/time/10/7.h>
#ifdef T
#include <my_ppmptd/time/10/8.h>
#ifdef T
#include <my_ppmptd/time/10/9.h>
#ifdef T
#include <my_ppmptd/time/10/10.h>
#ifdef T
#include <my_ppmptd/time/10/11.h>
#ifdef T
#include <my_ppmptd/time/10/12.h>
#ifdef T
#include <my_ppmptd/time/10/13.h>
#ifdef T
#include <my_ppmptd/time/10/14.h>
#ifdef T
#include <my_ppmptd/time/10/15.h>
#ifdef T
#include <my_ppmptd/time/10/16.h>
#ifdef T
#include <my_ppmptd/time/10/17.h>
#ifdef T
#include <my_ppmptd/time/10/18.h>
#ifdef T
#include <my_ppmptd/time/10/19.h>
#ifdef T
#include <my_ppmptd/time/10/20.h>
#ifdef T
#include <my_ppmptd/time/10/21.h>
#ifdef T
#include <my_ppmptd/time/10/22.h>
#ifdef T
#include <my_ppmptd/time/10/23.h>
#ifdef T
#include <my_ppmptd/time/10/24.h>
#ifdef T
#include <my_ppmptd/time/10/25.h>
#ifdef T
#include <my_ppmptd/time/10/26.h>
#ifdef T
#include <my_ppmptd/time/10/27.h>
#ifdef T
#include <my_ppmptd/time/10/28.h>
#ifdef T
#include <my_ppmptd/time/10/29.h>
#ifdef T
#include <my_ppmptd/time/10/30.h>
#ifdef T
#include <my_ppmptd/time/10/31.h>
#ifdef T
#include <my_ppmptd/time/10/32.h>
#ifdef T
#include <my_ppmptd/time/10/33.h>
#ifdef T
#include <my_ppmptd/time/10/34.h>
#ifdef T
#include <my_ppmptd/time/10/35.h>
#ifdef T
#include <my_ppmptd/time/10/36.h>
#ifdef T
#include <my_ppmptd/time/10/37.h>
#ifdef T
#include <my_ppmptd/time/10/38.h>
#ifdef T
#include <my_ppmptd/time/10/39.h>
#ifdef T
#include <my_ppmptd/time/10/40.h>
#ifdef T
#include <my_ppmptd/time/10/41.h>
#ifdef T
#include <my_ppmptd/time/10/42.h>
#ifdef T
#include <my_ppmptd/time/10/43.h>
#ifdef T
#include <my_ppmptd/time/10/44.h>
#ifdef T
#include <my_ppmptd/time/10/45.h>
#ifdef T
#include <my_ppmptd/time/10/46.h>
#ifdef T
#include <my_ppmptd/time/10/47.h>
#ifdef T
#include <my_ppmptd/time/10/48.h>
#ifdef T
#include <my_ppmptd/time/10/49.h>
#ifdef T
#include <my_ppmptd/time/10/50.h>
#ifdef T
#include <my_ppmptd/time/10/51.h>
#ifdef T
#include <my_ppmptd/time/10/52.h>
#ifdef T
#include <my_ppmptd/time/10/53.h>
#ifdef T
#include <my_ppmptd/time/10/54.h>
#ifdef T
#include <my_ppmptd/time/10/55.h>
#ifdef T
#include <my_ppmptd/time/10/56.h>
#ifdef T
#include <my_ppmptd/time/10/57.h>
#ifdef T
#include <my_ppmptd/time/10/58.h>
#ifdef T
#include <my_ppmptd/time/10/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/11/0.h>
#ifdef T
#include <my_ppmptd/time/11/1.h>
#ifdef T
#include <my_ppmptd/time/11/2.h>
#ifdef T
#include <my_ppmptd/time/11/3.h>
#ifdef T
#include <my_ppmptd/time/11/4.h>
#ifdef T
#include <my_ppmptd/time/11/5.h>
#ifdef T
#include <my_ppmptd/time/11/6.h>
#ifdef T
#include <my_ppmptd/time/11/7.h>
#ifdef T
#include <my_ppmptd/time/11/8.h>
#ifdef T
#include <my_ppmptd/time/11/9.h>
#ifdef T
#include <my_ppmptd/time/11/10.h>
#ifdef T
#include <my_ppmptd/time/11/11.h>
#ifdef T
#include <my_ppmptd/time/11/12.h>
#ifdef T
#include <my_ppmptd/time/11/13.h>
#ifdef T
#include <my_ppmptd/time/11/14.h>
#ifdef T
#include <my_ppmptd/time/11/15.h>
#ifdef T
#include <my_ppmptd/time/11/16.h>
#ifdef T
#include <my_ppmptd/time/11/17.h>
#ifdef T
#include <my_ppmptd/time/11/18.h>
#ifdef T
#include <my_ppmptd/time/11/19.h>
#ifdef T
#include <my_ppmptd/time/11/20.h>
#ifdef T
#include <my_ppmptd/time/11/21.h>
#ifdef T
#include <my_ppmptd/time/11/22.h>
#ifdef T
#include <my_ppmptd/time/11/23.h>
#ifdef T
#include <my_ppmptd/time/11/24.h>
#ifdef T
#include <my_ppmptd/time/11/25.h>
#ifdef T
#include <my_ppmptd/time/11/26.h>
#ifdef T
#include <my_ppmptd/time/11/27.h>
#ifdef T
#include <my_ppmptd/time/11/28.h>
#ifdef T
#include <my_ppmptd/time/11/29.h>
#ifdef T
#include <my_ppmptd/time/11/30.h>
#ifdef T
#include <my_ppmptd/time/11/31.h>
#ifdef T
#include <my_ppmptd/time/11/32.h>
#ifdef T
#include <my_ppmptd/time/11/33.h>
#ifdef T
#include <my_ppmptd/time/11/34.h>
#ifdef T
#include <my_ppmptd/time/11/35.h>
#ifdef T
#include <my_ppmptd/time/11/36.h>
#ifdef T
#include <my_ppmptd/time/11/37.h>
#ifdef T
#include <my_ppmptd/time/11/38.h>
#ifdef T
#include <my_ppmptd/time/11/39.h>
#ifdef T
#include <my_ppmptd/time/11/40.h>
#ifdef T
#include <my_ppmptd/time/11/41.h>
#ifdef T
#include <my_ppmptd/time/11/42.h>
#ifdef T
#include <my_ppmptd/time/11/43.h>
#ifdef T
#include <my_ppmptd/time/11/44.h>
#ifdef T
#include <my_ppmptd/time/11/45.h>
#ifdef T
#include <my_ppmptd/time/11/46.h>
#ifdef T
#include <my_ppmptd/time/11/47.h>
#ifdef T
#include <my_ppmptd/time/11/48.h>
#ifdef T
#include <my_ppmptd/time/11/49.h>
#ifdef T
#include <my_ppmptd/time/11/50.h>
#ifdef T
#include <my_ppmptd/time/11/51.h>
#ifdef T
#include <my_ppmptd/time/11/52.h>
#ifdef T
#include <my_ppmptd/time/11/53.h>
#ifdef T
#include <my_ppmptd/time/11/54.h>
#ifdef T
#include <my_ppmptd/time/11/55.h>
#ifdef T
#include <my_ppmptd/time/11/56.h>
#ifdef T
#include <my_ppmptd/time/11/57.h>
#ifdef T
#include <my_ppmptd/time/11/58.h>
#ifdef T
#include <my_ppmptd/time/11/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/12/0.h>
#ifdef T
#include <my_ppmptd/time/12/1.h>
#ifdef T
#include <my_ppmptd/time/12/2.h>
#ifdef T
#include <my_ppmptd/time/12/3.h>
#ifdef T
#include <my_ppmptd/time/12/4.h>
#ifdef T
#include <my_ppmptd/time/12/5.h>
#ifdef T
#include <my_ppmptd/time/12/6.h>
#ifdef T
#include <my_ppmptd/time/12/7.h>
#ifdef T
#include <my_ppmptd/time/12/8.h>
#ifdef T
#include <my_ppmptd/time/12/9.h>
#ifdef T
#include <my_ppmptd/time/12/10.h>
#ifdef T
#include <my_ppmptd/time/12/11.h>
#ifdef T
#include <my_ppmptd/time/12/12.h>
#ifdef T
#include <my_ppmptd/time/12/13.h>
#ifdef T
#include <my_ppmptd/time/12/14.h>
#ifdef T
#include <my_ppmptd/time/12/15.h>
#ifdef T
#include <my_ppmptd/time/12/16.h>
#ifdef T
#include <my_ppmptd/time/12/17.h>
#ifdef T
#include <my_ppmptd/time/12/18.h>
#ifdef T
#include <my_ppmptd/time/12/19.h>
#ifdef T
#include <my_ppmptd/time/12/20.h>
#ifdef T
#include <my_ppmptd/time/12/21.h>
#ifdef T
#include <my_ppmptd/time/12/22.h>
#ifdef T
#include <my_ppmptd/time/12/23.h>
#ifdef T
#include <my_ppmptd/time/12/24.h>
#ifdef T
#include <my_ppmptd/time/12/25.h>
#ifdef T
#include <my_ppmptd/time/12/26.h>
#ifdef T
#include <my_ppmptd/time/12/27.h>
#ifdef T
#include <my_ppmptd/time/12/28.h>
#ifdef T
#include <my_ppmptd/time/12/29.h>
#ifdef T
#include <my_ppmptd/time/12/30.h>
#ifdef T
#include <my_ppmptd/time/12/31.h>
#ifdef T
#include <my_ppmptd/time/12/32.h>
#ifdef T
#include <my_ppmptd/time/12/33.h>
#ifdef T
#include <my_ppmptd/time/12/34.h>
#ifdef T
#include <my_ppmptd/time/12/35.h>
#ifdef T
#include <my_ppmptd/time/12/36.h>
#ifdef T
#include <my_ppmptd/time/12/37.h>
#ifdef T
#include <my_ppmptd/time/12/38.h>
#ifdef T
#include <my_ppmptd/time/12/39.h>
#ifdef T
#include <my_ppmptd/time/12/40.h>
#ifdef T
#include <my_ppmptd/time/12/41.h>
#ifdef T
#include <my_ppmptd/time/12/42.h>
#ifdef T
#include <my_ppmptd/time/12/43.h>
#ifdef T
#include <my_ppmptd/time/12/44.h>
#ifdef T
#include <my_ppmptd/time/12/45.h>
#ifdef T
#include <my_ppmptd/time/12/46.h>
#ifdef T
#include <my_ppmptd/time/12/47.h>
#ifdef T
#include <my_ppmptd/time/12/48.h>
#ifdef T
#include <my_ppmptd/time/12/49.h>
#ifdef T
#include <my_ppmptd/time/12/50.h>
#ifdef T
#include <my_ppmptd/time/12/51.h>
#ifdef T
#include <my_ppmptd/time/12/52.h>
#ifdef T
#include <my_ppmptd/time/12/53.h>
#ifdef T
#include <my_ppmptd/time/12/54.h>
#ifdef T
#include <my_ppmptd/time/12/55.h>
#ifdef T
#include <my_ppmptd/time/12/56.h>
#ifdef T
#include <my_ppmptd/time/12/57.h>
#ifdef T
#include <my_ppmptd/time/12/58.h>
#ifdef T
#include <my_ppmptd/time/12/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/13/0.h>
#ifdef T
#include <my_ppmptd/time/13/1.h>
#ifdef T
#include <my_ppmptd/time/13/2.h>
#ifdef T
#include <my_ppmptd/time/13/3.h>
#ifdef T
#include <my_ppmptd/time/13/4.h>
#ifdef T
#include <my_ppmptd/time/13/5.h>
#ifdef T
#include <my_ppmptd/time/13/6.h>
#ifdef T
#include <my_ppmptd/time/13/7.h>
#ifdef T
#include <my_ppmptd/time/13/8.h>
#ifdef T
#include <my_ppmptd/time/13/9.h>
#ifdef T
#include <my_ppmptd/time/13/10.h>
#ifdef T
#include <my_ppmptd/time/13/11.h>
#ifdef T
#include <my_ppmptd/time/13/12.h>
#ifdef T
#include <my_ppmptd/time/13/13.h>
#ifdef T
#include <my_ppmptd/time/13/14.h>
#ifdef T
#include <my_ppmptd/time/13/15.h>
#ifdef T
#include <my_ppmptd/time/13/16.h>
#ifdef T
#include <my_ppmptd/time/13/17.h>
#ifdef T
#include <my_ppmptd/time/13/18.h>
#ifdef T
#include <my_ppmptd/time/13/19.h>
#ifdef T
#include <my_ppmptd/time/13/20.h>
#ifdef T
#include <my_ppmptd/time/13/21.h>
#ifdef T
#include <my_ppmptd/time/13/22.h>
#ifdef T
#include <my_ppmptd/time/13/23.h>
#ifdef T
#include <my_ppmptd/time/13/24.h>
#ifdef T
#include <my_ppmptd/time/13/25.h>
#ifdef T
#include <my_ppmptd/time/13/26.h>
#ifdef T
#include <my_ppmptd/time/13/27.h>
#ifdef T
#include <my_ppmptd/time/13/28.h>
#ifdef T
#include <my_ppmptd/time/13/29.h>
#ifdef T
#include <my_ppmptd/time/13/30.h>
#ifdef T
#include <my_ppmptd/time/13/31.h>
#ifdef T
#include <my_ppmptd/time/13/32.h>
#ifdef T
#include <my_ppmptd/time/13/33.h>
#ifdef T
#include <my_ppmptd/time/13/34.h>
#ifdef T
#include <my_ppmptd/time/13/35.h>
#ifdef T
#include <my_ppmptd/time/13/36.h>
#ifdef T
#include <my_ppmptd/time/13/37.h>
#ifdef T
#include <my_ppmptd/time/13/38.h>
#ifdef T
#include <my_ppmptd/time/13/39.h>
#ifdef T
#include <my_ppmptd/time/13/40.h>
#ifdef T
#include <my_ppmptd/time/13/41.h>
#ifdef T
#include <my_ppmptd/time/13/42.h>
#ifdef T
#include <my_ppmptd/time/13/43.h>
#ifdef T
#include <my_ppmptd/time/13/44.h>
#ifdef T
#include <my_ppmptd/time/13/45.h>
#ifdef T
#include <my_ppmptd/time/13/46.h>
#ifdef T
#include <my_ppmptd/time/13/47.h>
#ifdef T
#include <my_ppmptd/time/13/48.h>
#ifdef T
#include <my_ppmptd/time/13/49.h>
#ifdef T
#include <my_ppmptd/time/13/50.h>
#ifdef T
#include <my_ppmptd/time/13/51.h>
#ifdef T
#include <my_ppmptd/time/13/52.h>
#ifdef T
#include <my_ppmptd/time/13/53.h>
#ifdef T
#include <my_ppmptd/time/13/54.h>
#ifdef T
#include <my_ppmptd/time/13/55.h>
#ifdef T
#include <my_ppmptd/time/13/56.h>
#ifdef T
#include <my_ppmptd/time/13/57.h>
#ifdef T
#include <my_ppmptd/time/13/58.h>
#ifdef T
#include <my_ppmptd/time/13/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/14/0.h>
#ifdef T
#include <my_ppmptd/time/14/1.h>
#ifdef T
#include <my_ppmptd/time/14/2.h>
#ifdef T
#include <my_ppmptd/time/14/3.h>
#ifdef T
#include <my_ppmptd/time/14/4.h>
#ifdef T
#include <my_ppmptd/time/14/5.h>
#ifdef T
#include <my_ppmptd/time/14/6.h>
#ifdef T
#include <my_ppmptd/time/14/7.h>
#ifdef T
#include <my_ppmptd/time/14/8.h>
#ifdef T
#include <my_ppmptd/time/14/9.h>
#ifdef T
#include <my_ppmptd/time/14/10.h>
#ifdef T
#include <my_ppmptd/time/14/11.h>
#ifdef T
#include <my_ppmptd/time/14/12.h>
#ifdef T
#include <my_ppmptd/time/14/13.h>
#ifdef T
#include <my_ppmptd/time/14/14.h>
#ifdef T
#include <my_ppmptd/time/14/15.h>
#ifdef T
#include <my_ppmptd/time/14/16.h>
#ifdef T
#include <my_ppmptd/time/14/17.h>
#ifdef T
#include <my_ppmptd/time/14/18.h>
#ifdef T
#include <my_ppmptd/time/14/19.h>
#ifdef T
#include <my_ppmptd/time/14/20.h>
#ifdef T
#include <my_ppmptd/time/14/21.h>
#ifdef T
#include <my_ppmptd/time/14/22.h>
#ifdef T
#include <my_ppmptd/time/14/23.h>
#ifdef T
#include <my_ppmptd/time/14/24.h>
#ifdef T
#include <my_ppmptd/time/14/25.h>
#ifdef T
#include <my_ppmptd/time/14/26.h>
#ifdef T
#include <my_ppmptd/time/14/27.h>
#ifdef T
#include <my_ppmptd/time/14/28.h>
#ifdef T
#include <my_ppmptd/time/14/29.h>
#ifdef T
#include <my_ppmptd/time/14/30.h>
#ifdef T
#include <my_ppmptd/time/14/31.h>
#ifdef T
#include <my_ppmptd/time/14/32.h>
#ifdef T
#include <my_ppmptd/time/14/33.h>
#ifdef T
#include <my_ppmptd/time/14/34.h>
#ifdef T
#include <my_ppmptd/time/14/35.h>
#ifdef T
#include <my_ppmptd/time/14/36.h>
#ifdef T
#include <my_ppmptd/time/14/37.h>
#ifdef T
#include <my_ppmptd/time/14/38.h>
#ifdef T
#include <my_ppmptd/time/14/39.h>
#ifdef T
#include <my_ppmptd/time/14/40.h>
#ifdef T
#include <my_ppmptd/time/14/41.h>
#ifdef T
#include <my_ppmptd/time/14/42.h>
#ifdef T
#include <my_ppmptd/time/14/43.h>
#ifdef T
#include <my_ppmptd/time/14/44.h>
#ifdef T
#include <my_ppmptd/time/14/45.h>
#ifdef T
#include <my_ppmptd/time/14/46.h>
#ifdef T
#include <my_ppmptd/time/14/47.h>
#ifdef T
#include <my_ppmptd/time/14/48.h>
#ifdef T
#include <my_ppmptd/time/14/49.h>
#ifdef T
#include <my_ppmptd/time/14/50.h>
#ifdef T
#include <my_ppmptd/time/14/51.h>
#ifdef T
#include <my_ppmptd/time/14/52.h>
#ifdef T
#include <my_ppmptd/time/14/53.h>
#ifdef T
#include <my_ppmptd/time/14/54.h>
#ifdef T
#include <my_ppmptd/time/14/55.h>
#ifdef T
#include <my_ppmptd/time/14/56.h>
#ifdef T
#include <my_ppmptd/time/14/57.h>
#ifdef T
#include <my_ppmptd/time/14/58.h>
#ifdef T
#include <my_ppmptd/time/14/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/15/0.h>
#ifdef T
#include <my_ppmptd/time/15/1.h>
#ifdef T
#include <my_ppmptd/time/15/2.h>
#ifdef T
#include <my_ppmptd/time/15/3.h>
#ifdef T
#include <my_ppmptd/time/15/4.h>
#ifdef T
#include <my_ppmptd/time/15/5.h>
#ifdef T
#include <my_ppmptd/time/15/6.h>
#ifdef T
#include <my_ppmptd/time/15/7.h>
#ifdef T
#include <my_ppmptd/time/15/8.h>
#ifdef T
#include <my_ppmptd/time/15/9.h>
#ifdef T
#include <my_ppmptd/time/15/10.h>
#ifdef T
#include <my_ppmptd/time/15/11.h>
#ifdef T
#include <my_ppmptd/time/15/12.h>
#ifdef T
#include <my_ppmptd/time/15/13.h>
#ifdef T
#include <my_ppmptd/time/15/14.h>
#ifdef T
#include <my_ppmptd/time/15/15.h>
#ifdef T
#include <my_ppmptd/time/15/16.h>
#ifdef T
#include <my_ppmptd/time/15/17.h>
#ifdef T
#include <my_ppmptd/time/15/18.h>
#ifdef T
#include <my_ppmptd/time/15/19.h>
#ifdef T
#include <my_ppmptd/time/15/20.h>
#ifdef T
#include <my_ppmptd/time/15/21.h>
#ifdef T
#include <my_ppmptd/time/15/22.h>
#ifdef T
#include <my_ppmptd/time/15/23.h>
#ifdef T
#include <my_ppmptd/time/15/24.h>
#ifdef T
#include <my_ppmptd/time/15/25.h>
#ifdef T
#include <my_ppmptd/time/15/26.h>
#ifdef T
#include <my_ppmptd/time/15/27.h>
#ifdef T
#include <my_ppmptd/time/15/28.h>
#ifdef T
#include <my_ppmptd/time/15/29.h>
#ifdef T
#include <my_ppmptd/time/15/30.h>
#ifdef T
#include <my_ppmptd/time/15/31.h>
#ifdef T
#include <my_ppmptd/time/15/32.h>
#ifdef T
#include <my_ppmptd/time/15/33.h>
#ifdef T
#include <my_ppmptd/time/15/34.h>
#ifdef T
#include <my_ppmptd/time/15/35.h>
#ifdef T
#include <my_ppmptd/time/15/36.h>
#ifdef T
#include <my_ppmptd/time/15/37.h>
#ifdef T
#include <my_ppmptd/time/15/38.h>
#ifdef T
#include <my_ppmptd/time/15/39.h>
#ifdef T
#include <my_ppmptd/time/15/40.h>
#ifdef T
#include <my_ppmptd/time/15/41.h>
#ifdef T
#include <my_ppmptd/time/15/42.h>
#ifdef T
#include <my_ppmptd/time/15/43.h>
#ifdef T
#include <my_ppmptd/time/15/44.h>
#ifdef T
#include <my_ppmptd/time/15/45.h>
#ifdef T
#include <my_ppmptd/time/15/46.h>
#ifdef T
#include <my_ppmptd/time/15/47.h>
#ifdef T
#include <my_ppmptd/time/15/48.h>
#ifdef T
#include <my_ppmptd/time/15/49.h>
#ifdef T
#include <my_ppmptd/time/15/50.h>
#ifdef T
#include <my_ppmptd/time/15/51.h>
#ifdef T
#include <my_ppmptd/time/15/52.h>
#ifdef T
#include <my_ppmptd/time/15/53.h>
#ifdef T
#include <my_ppmptd/time/15/54.h>
#ifdef T
#include <my_ppmptd/time/15/55.h>
#ifdef T
#include <my_ppmptd/time/15/56.h>
#ifdef T
#include <my_ppmptd/time/15/57.h>
#ifdef T
#include <my_ppmptd/time/15/58.h>
#ifdef T
#include <my_ppmptd/time/15/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/16/0.h>
#ifdef T
#include <my_ppmptd/time/16/1.h>
#ifdef T
#include <my_ppmptd/time/16/2.h>
#ifdef T
#include <my_ppmptd/time/16/3.h>
#ifdef T
#include <my_ppmptd/time/16/4.h>
#ifdef T
#include <my_ppmptd/time/16/5.h>
#ifdef T
#include <my_ppmptd/time/16/6.h>
#ifdef T
#include <my_ppmptd/time/16/7.h>
#ifdef T
#include <my_ppmptd/time/16/8.h>
#ifdef T
#include <my_ppmptd/time/16/9.h>
#ifdef T
#include <my_ppmptd/time/16/10.h>
#ifdef T
#include <my_ppmptd/time/16/11.h>
#ifdef T
#include <my_ppmptd/time/16/12.h>
#ifdef T
#include <my_ppmptd/time/16/13.h>
#ifdef T
#include <my_ppmptd/time/16/14.h>
#ifdef T
#include <my_ppmptd/time/16/15.h>
#ifdef T
#include <my_ppmptd/time/16/16.h>
#ifdef T
#include <my_ppmptd/time/16/17.h>
#ifdef T
#include <my_ppmptd/time/16/18.h>
#ifdef T
#include <my_ppmptd/time/16/19.h>
#ifdef T
#include <my_ppmptd/time/16/20.h>
#ifdef T
#include <my_ppmptd/time/16/21.h>
#ifdef T
#include <my_ppmptd/time/16/22.h>
#ifdef T
#include <my_ppmptd/time/16/23.h>
#ifdef T
#include <my_ppmptd/time/16/24.h>
#ifdef T
#include <my_ppmptd/time/16/25.h>
#ifdef T
#include <my_ppmptd/time/16/26.h>
#ifdef T
#include <my_ppmptd/time/16/27.h>
#ifdef T
#include <my_ppmptd/time/16/28.h>
#ifdef T
#include <my_ppmptd/time/16/29.h>
#ifdef T
#include <my_ppmptd/time/16/30.h>
#ifdef T
#include <my_ppmptd/time/16/31.h>
#ifdef T
#include <my_ppmptd/time/16/32.h>
#ifdef T
#include <my_ppmptd/time/16/33.h>
#ifdef T
#include <my_ppmptd/time/16/34.h>
#ifdef T
#include <my_ppmptd/time/16/35.h>
#ifdef T
#include <my_ppmptd/time/16/36.h>
#ifdef T
#include <my_ppmptd/time/16/37.h>
#ifdef T
#include <my_ppmptd/time/16/38.h>
#ifdef T
#include <my_ppmptd/time/16/39.h>
#ifdef T
#include <my_ppmptd/time/16/40.h>
#ifdef T
#include <my_ppmptd/time/16/41.h>
#ifdef T
#include <my_ppmptd/time/16/42.h>
#ifdef T
#include <my_ppmptd/time/16/43.h>
#ifdef T
#include <my_ppmptd/time/16/44.h>
#ifdef T
#include <my_ppmptd/time/16/45.h>
#ifdef T
#include <my_ppmptd/time/16/46.h>
#ifdef T
#include <my_ppmptd/time/16/47.h>
#ifdef T
#include <my_ppmptd/time/16/48.h>
#ifdef T
#include <my_ppmptd/time/16/49.h>
#ifdef T
#include <my_ppmptd/time/16/50.h>
#ifdef T
#include <my_ppmptd/time/16/51.h>
#ifdef T
#include <my_ppmptd/time/16/52.h>
#ifdef T
#include <my_ppmptd/time/16/53.h>
#ifdef T
#include <my_ppmptd/time/16/54.h>
#ifdef T
#include <my_ppmptd/time/16/55.h>
#ifdef T
#include <my_ppmptd/time/16/56.h>
#ifdef T
#include <my_ppmptd/time/16/57.h>
#ifdef T
#include <my_ppmptd/time/16/58.h>
#ifdef T
#include <my_ppmptd/time/16/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/17/0.h>
#ifdef T
#include <my_ppmptd/time/17/1.h>
#ifdef T
#include <my_ppmptd/time/17/2.h>
#ifdef T
#include <my_ppmptd/time/17/3.h>
#ifdef T
#include <my_ppmptd/time/17/4.h>
#ifdef T
#include <my_ppmptd/time/17/5.h>
#ifdef T
#include <my_ppmptd/time/17/6.h>
#ifdef T
#include <my_ppmptd/time/17/7.h>
#ifdef T
#include <my_ppmptd/time/17/8.h>
#ifdef T
#include <my_ppmptd/time/17/9.h>
#ifdef T
#include <my_ppmptd/time/17/10.h>
#ifdef T
#include <my_ppmptd/time/17/11.h>
#ifdef T
#include <my_ppmptd/time/17/12.h>
#ifdef T
#include <my_ppmptd/time/17/13.h>
#ifdef T
#include <my_ppmptd/time/17/14.h>
#ifdef T
#include <my_ppmptd/time/17/15.h>
#ifdef T
#include <my_ppmptd/time/17/16.h>
#ifdef T
#include <my_ppmptd/time/17/17.h>
#ifdef T
#include <my_ppmptd/time/17/18.h>
#ifdef T
#include <my_ppmptd/time/17/19.h>
#ifdef T
#include <my_ppmptd/time/17/20.h>
#ifdef T
#include <my_ppmptd/time/17/21.h>
#ifdef T
#include <my_ppmptd/time/17/22.h>
#ifdef T
#include <my_ppmptd/time/17/23.h>
#ifdef T
#include <my_ppmptd/time/17/24.h>
#ifdef T
#include <my_ppmptd/time/17/25.h>
#ifdef T
#include <my_ppmptd/time/17/26.h>
#ifdef T
#include <my_ppmptd/time/17/27.h>
#ifdef T
#include <my_ppmptd/time/17/28.h>
#ifdef T
#include <my_ppmptd/time/17/29.h>
#ifdef T
#include <my_ppmptd/time/17/30.h>
#ifdef T
#include <my_ppmptd/time/17/31.h>
#ifdef T
#include <my_ppmptd/time/17/32.h>
#ifdef T
#include <my_ppmptd/time/17/33.h>
#ifdef T
#include <my_ppmptd/time/17/34.h>
#ifdef T
#include <my_ppmptd/time/17/35.h>
#ifdef T
#include <my_ppmptd/time/17/36.h>
#ifdef T
#include <my_ppmptd/time/17/37.h>
#ifdef T
#include <my_ppmptd/time/17/38.h>
#ifdef T
#include <my_ppmptd/time/17/39.h>
#ifdef T
#include <my_ppmptd/time/17/40.h>
#ifdef T
#include <my_ppmptd/time/17/41.h>
#ifdef T
#include <my_ppmptd/time/17/42.h>
#ifdef T
#include <my_ppmptd/time/17/43.h>
#ifdef T
#include <my_ppmptd/time/17/44.h>
#ifdef T
#include <my_ppmptd/time/17/45.h>
#ifdef T
#include <my_ppmptd/time/17/46.h>
#ifdef T
#include <my_ppmptd/time/17/47.h>
#ifdef T
#include <my_ppmptd/time/17/48.h>
#ifdef T
#include <my_ppmptd/time/17/49.h>
#ifdef T
#include <my_ppmptd/time/17/50.h>
#ifdef T
#include <my_ppmptd/time/17/51.h>
#ifdef T
#include <my_ppmptd/time/17/52.h>
#ifdef T
#include <my_ppmptd/time/17/53.h>
#ifdef T
#include <my_ppmptd/time/17/54.h>
#ifdef T
#include <my_ppmptd/time/17/55.h>
#ifdef T
#include <my_ppmptd/time/17/56.h>
#ifdef T
#include <my_ppmptd/time/17/57.h>
#ifdef T
#include <my_ppmptd/time/17/58.h>
#ifdef T
#include <my_ppmptd/time/17/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/18/0.h>
#ifdef T
#include <my_ppmptd/time/18/1.h>
#ifdef T
#include <my_ppmptd/time/18/2.h>
#ifdef T
#include <my_ppmptd/time/18/3.h>
#ifdef T
#include <my_ppmptd/time/18/4.h>
#ifdef T
#include <my_ppmptd/time/18/5.h>
#ifdef T
#include <my_ppmptd/time/18/6.h>
#ifdef T
#include <my_ppmptd/time/18/7.h>
#ifdef T
#include <my_ppmptd/time/18/8.h>
#ifdef T
#include <my_ppmptd/time/18/9.h>
#ifdef T
#include <my_ppmptd/time/18/10.h>
#ifdef T
#include <my_ppmptd/time/18/11.h>
#ifdef T
#include <my_ppmptd/time/18/12.h>
#ifdef T
#include <my_ppmptd/time/18/13.h>
#ifdef T
#include <my_ppmptd/time/18/14.h>
#ifdef T
#include <my_ppmptd/time/18/15.h>
#ifdef T
#include <my_ppmptd/time/18/16.h>
#ifdef T
#include <my_ppmptd/time/18/17.h>
#ifdef T
#include <my_ppmptd/time/18/18.h>
#ifdef T
#include <my_ppmptd/time/18/19.h>
#ifdef T
#include <my_ppmptd/time/18/20.h>
#ifdef T
#include <my_ppmptd/time/18/21.h>
#ifdef T
#include <my_ppmptd/time/18/22.h>
#ifdef T
#include <my_ppmptd/time/18/23.h>
#ifdef T
#include <my_ppmptd/time/18/24.h>
#ifdef T
#include <my_ppmptd/time/18/25.h>
#ifdef T
#include <my_ppmptd/time/18/26.h>
#ifdef T
#include <my_ppmptd/time/18/27.h>
#ifdef T
#include <my_ppmptd/time/18/28.h>
#ifdef T
#include <my_ppmptd/time/18/29.h>
#ifdef T
#include <my_ppmptd/time/18/30.h>
#ifdef T
#include <my_ppmptd/time/18/31.h>
#ifdef T
#include <my_ppmptd/time/18/32.h>
#ifdef T
#include <my_ppmptd/time/18/33.h>
#ifdef T
#include <my_ppmptd/time/18/34.h>
#ifdef T
#include <my_ppmptd/time/18/35.h>
#ifdef T
#include <my_ppmptd/time/18/36.h>
#ifdef T
#include <my_ppmptd/time/18/37.h>
#ifdef T
#include <my_ppmptd/time/18/38.h>
#ifdef T
#include <my_ppmptd/time/18/39.h>
#ifdef T
#include <my_ppmptd/time/18/40.h>
#ifdef T
#include <my_ppmptd/time/18/41.h>
#ifdef T
#include <my_ppmptd/time/18/42.h>
#ifdef T
#include <my_ppmptd/time/18/43.h>
#ifdef T
#include <my_ppmptd/time/18/44.h>
#ifdef T
#include <my_ppmptd/time/18/45.h>
#ifdef T
#include <my_ppmptd/time/18/46.h>
#ifdef T
#include <my_ppmptd/time/18/47.h>
#ifdef T
#include <my_ppmptd/time/18/48.h>
#ifdef T
#include <my_ppmptd/time/18/49.h>
#ifdef T
#include <my_ppmptd/time/18/50.h>
#ifdef T
#include <my_ppmptd/time/18/51.h>
#ifdef T
#include <my_ppmptd/time/18/52.h>
#ifdef T
#include <my_ppmptd/time/18/53.h>
#ifdef T
#include <my_ppmptd/time/18/54.h>
#ifdef T
#include <my_ppmptd/time/18/55.h>
#ifdef T
#include <my_ppmptd/time/18/56.h>
#ifdef T
#include <my_ppmptd/time/18/57.h>
#ifdef T
#include <my_ppmptd/time/18/58.h>
#ifdef T
#include <my_ppmptd/time/18/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/19/0.h>
#ifdef T
#include <my_ppmptd/time/19/1.h>
#ifdef T
#include <my_ppmptd/time/19/2.h>
#ifdef T
#include <my_ppmptd/time/19/3.h>
#ifdef T
#include <my_ppmptd/time/19/4.h>
#ifdef T
#include <my_ppmptd/time/19/5.h>
#ifdef T
#include <my_ppmptd/time/19/6.h>
#ifdef T
#include <my_ppmptd/time/19/7.h>
#ifdef T
#include <my_ppmptd/time/19/8.h>
#ifdef T
#include <my_ppmptd/time/19/9.h>
#ifdef T
#include <my_ppmptd/time/19/10.h>
#ifdef T
#include <my_ppmptd/time/19/11.h>
#ifdef T
#include <my_ppmptd/time/19/12.h>
#ifdef T
#include <my_ppmptd/time/19/13.h>
#ifdef T
#include <my_ppmptd/time/19/14.h>
#ifdef T
#include <my_ppmptd/time/19/15.h>
#ifdef T
#include <my_ppmptd/time/19/16.h>
#ifdef T
#include <my_ppmptd/time/19/17.h>
#ifdef T
#include <my_ppmptd/time/19/18.h>
#ifdef T
#include <my_ppmptd/time/19/19.h>
#ifdef T
#include <my_ppmptd/time/19/20.h>
#ifdef T
#include <my_ppmptd/time/19/21.h>
#ifdef T
#include <my_ppmptd/time/19/22.h>
#ifdef T
#include <my_ppmptd/time/19/23.h>
#ifdef T
#include <my_ppmptd/time/19/24.h>
#ifdef T
#include <my_ppmptd/time/19/25.h>
#ifdef T
#include <my_ppmptd/time/19/26.h>
#ifdef T
#include <my_ppmptd/time/19/27.h>
#ifdef T
#include <my_ppmptd/time/19/28.h>
#ifdef T
#include <my_ppmptd/time/19/29.h>
#ifdef T
#include <my_ppmptd/time/19/30.h>
#ifdef T
#include <my_ppmptd/time/19/31.h>
#ifdef T
#include <my_ppmptd/time/19/32.h>
#ifdef T
#include <my_ppmptd/time/19/33.h>
#ifdef T
#include <my_ppmptd/time/19/34.h>
#ifdef T
#include <my_ppmptd/time/19/35.h>
#ifdef T
#include <my_ppmptd/time/19/36.h>
#ifdef T
#include <my_ppmptd/time/19/37.h>
#ifdef T
#include <my_ppmptd/time/19/38.h>
#ifdef T
#include <my_ppmptd/time/19/39.h>
#ifdef T
#include <my_ppmptd/time/19/40.h>
#ifdef T
#include <my_ppmptd/time/19/41.h>
#ifdef T
#include <my_ppmptd/time/19/42.h>
#ifdef T
#include <my_ppmptd/time/19/43.h>
#ifdef T
#include <my_ppmptd/time/19/44.h>
#ifdef T
#include <my_ppmptd/time/19/45.h>
#ifdef T
#include <my_ppmptd/time/19/46.h>
#ifdef T
#include <my_ppmptd/time/19/47.h>
#ifdef T
#include <my_ppmptd/time/19/48.h>
#ifdef T
#include <my_ppmptd/time/19/49.h>
#ifdef T
#include <my_ppmptd/time/19/50.h>
#ifdef T
#include <my_ppmptd/time/19/51.h>
#ifdef T
#include <my_ppmptd/time/19/52.h>
#ifdef T
#include <my_ppmptd/time/19/53.h>
#ifdef T
#include <my_ppmptd/time/19/54.h>
#ifdef T
#include <my_ppmptd/time/19/55.h>
#ifdef T
#include <my_ppmptd/time/19/56.h>
#ifdef T
#include <my_ppmptd/time/19/57.h>
#ifdef T
#include <my_ppmptd/time/19/58.h>
#ifdef T
#include <my_ppmptd/time/19/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/20/0.h>
#ifdef T
#include <my_ppmptd/time/20/1.h>
#ifdef T
#include <my_ppmptd/time/20/2.h>
#ifdef T
#include <my_ppmptd/time/20/3.h>
#ifdef T
#include <my_ppmptd/time/20/4.h>
#ifdef T
#include <my_ppmptd/time/20/5.h>
#ifdef T
#include <my_ppmptd/time/20/6.h>
#ifdef T
#include <my_ppmptd/time/20/7.h>
#ifdef T
#include <my_ppmptd/time/20/8.h>
#ifdef T
#include <my_ppmptd/time/20/9.h>
#ifdef T
#include <my_ppmptd/time/20/10.h>
#ifdef T
#include <my_ppmptd/time/20/11.h>
#ifdef T
#include <my_ppmptd/time/20/12.h>
#ifdef T
#include <my_ppmptd/time/20/13.h>
#ifdef T
#include <my_ppmptd/time/20/14.h>
#ifdef T
#include <my_ppmptd/time/20/15.h>
#ifdef T
#include <my_ppmptd/time/20/16.h>
#ifdef T
#include <my_ppmptd/time/20/17.h>
#ifdef T
#include <my_ppmptd/time/20/18.h>
#ifdef T
#include <my_ppmptd/time/20/19.h>
#ifdef T
#include <my_ppmptd/time/20/20.h>
#ifdef T
#include <my_ppmptd/time/20/21.h>
#ifdef T
#include <my_ppmptd/time/20/22.h>
#ifdef T
#include <my_ppmptd/time/20/23.h>
#ifdef T
#include <my_ppmptd/time/20/24.h>
#ifdef T
#include <my_ppmptd/time/20/25.h>
#ifdef T
#include <my_ppmptd/time/20/26.h>
#ifdef T
#include <my_ppmptd/time/20/27.h>
#ifdef T
#include <my_ppmptd/time/20/28.h>
#ifdef T
#include <my_ppmptd/time/20/29.h>
#ifdef T
#include <my_ppmptd/time/20/30.h>
#ifdef T
#include <my_ppmptd/time/20/31.h>
#ifdef T
#include <my_ppmptd/time/20/32.h>
#ifdef T
#include <my_ppmptd/time/20/33.h>
#ifdef T
#include <my_ppmptd/time/20/34.h>
#ifdef T
#include <my_ppmptd/time/20/35.h>
#ifdef T
#include <my_ppmptd/time/20/36.h>
#ifdef T
#include <my_ppmptd/time/20/37.h>
#ifdef T
#include <my_ppmptd/time/20/38.h>
#ifdef T
#include <my_ppmptd/time/20/39.h>
#ifdef T
#include <my_ppmptd/time/20/40.h>
#ifdef T
#include <my_ppmptd/time/20/41.h>
#ifdef T
#include <my_ppmptd/time/20/42.h>
#ifdef T
#include <my_ppmptd/time/20/43.h>
#ifdef T
#include <my_ppmptd/time/20/44.h>
#ifdef T
#include <my_ppmptd/time/20/45.h>
#ifdef T
#include <my_ppmptd/time/20/46.h>
#ifdef T
#include <my_ppmptd/time/20/47.h>
#ifdef T
#include <my_ppmptd/time/20/48.h>
#ifdef T
#include <my_ppmptd/time/20/49.h>
#ifdef T
#include <my_ppmptd/time/20/50.h>
#ifdef T
#include <my_ppmptd/time/20/51.h>
#ifdef T
#include <my_ppmptd/time/20/52.h>
#ifdef T
#include <my_ppmptd/time/20/53.h>
#ifdef T
#include <my_ppmptd/time/20/54.h>
#ifdef T
#include <my_ppmptd/time/20/55.h>
#ifdef T
#include <my_ppmptd/time/20/56.h>
#ifdef T
#include <my_ppmptd/time/20/57.h>
#ifdef T
#include <my_ppmptd/time/20/58.h>
#ifdef T
#include <my_ppmptd/time/20/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/21/0.h>
#ifdef T
#include <my_ppmptd/time/21/1.h>
#ifdef T
#include <my_ppmptd/time/21/2.h>
#ifdef T
#include <my_ppmptd/time/21/3.h>
#ifdef T
#include <my_ppmptd/time/21/4.h>
#ifdef T
#include <my_ppmptd/time/21/5.h>
#ifdef T
#include <my_ppmptd/time/21/6.h>
#ifdef T
#include <my_ppmptd/time/21/7.h>
#ifdef T
#include <my_ppmptd/time/21/8.h>
#ifdef T
#include <my_ppmptd/time/21/9.h>
#ifdef T
#include <my_ppmptd/time/21/10.h>
#ifdef T
#include <my_ppmptd/time/21/11.h>
#ifdef T
#include <my_ppmptd/time/21/12.h>
#ifdef T
#include <my_ppmptd/time/21/13.h>
#ifdef T
#include <my_ppmptd/time/21/14.h>
#ifdef T
#include <my_ppmptd/time/21/15.h>
#ifdef T
#include <my_ppmptd/time/21/16.h>
#ifdef T
#include <my_ppmptd/time/21/17.h>
#ifdef T
#include <my_ppmptd/time/21/18.h>
#ifdef T
#include <my_ppmptd/time/21/19.h>
#ifdef T
#include <my_ppmptd/time/21/20.h>
#ifdef T
#include <my_ppmptd/time/21/21.h>
#ifdef T
#include <my_ppmptd/time/21/22.h>
#ifdef T
#include <my_ppmptd/time/21/23.h>
#ifdef T
#include <my_ppmptd/time/21/24.h>
#ifdef T
#include <my_ppmptd/time/21/25.h>
#ifdef T
#include <my_ppmptd/time/21/26.h>
#ifdef T
#include <my_ppmptd/time/21/27.h>
#ifdef T
#include <my_ppmptd/time/21/28.h>
#ifdef T
#include <my_ppmptd/time/21/29.h>
#ifdef T
#include <my_ppmptd/time/21/30.h>
#ifdef T
#include <my_ppmptd/time/21/31.h>
#ifdef T
#include <my_ppmptd/time/21/32.h>
#ifdef T
#include <my_ppmptd/time/21/33.h>
#ifdef T
#include <my_ppmptd/time/21/34.h>
#ifdef T
#include <my_ppmptd/time/21/35.h>
#ifdef T
#include <my_ppmptd/time/21/36.h>
#ifdef T
#include <my_ppmptd/time/21/37.h>
#ifdef T
#include <my_ppmptd/time/21/38.h>
#ifdef T
#include <my_ppmptd/time/21/39.h>
#ifdef T
#include <my_ppmptd/time/21/40.h>
#ifdef T
#include <my_ppmptd/time/21/41.h>
#ifdef T
#include <my_ppmptd/time/21/42.h>
#ifdef T
#include <my_ppmptd/time/21/43.h>
#ifdef T
#include <my_ppmptd/time/21/44.h>
#ifdef T
#include <my_ppmptd/time/21/45.h>
#ifdef T
#include <my_ppmptd/time/21/46.h>
#ifdef T
#include <my_ppmptd/time/21/47.h>
#ifdef T
#include <my_ppmptd/time/21/48.h>
#ifdef T
#include <my_ppmptd/time/21/49.h>
#ifdef T
#include <my_ppmptd/time/21/50.h>
#ifdef T
#include <my_ppmptd/time/21/51.h>
#ifdef T
#include <my_ppmptd/time/21/52.h>
#ifdef T
#include <my_ppmptd/time/21/53.h>
#ifdef T
#include <my_ppmptd/time/21/54.h>
#ifdef T
#include <my_ppmptd/time/21/55.h>
#ifdef T
#include <my_ppmptd/time/21/56.h>
#ifdef T
#include <my_ppmptd/time/21/57.h>
#ifdef T
#include <my_ppmptd/time/21/58.h>
#ifdef T
#include <my_ppmptd/time/21/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/22/0.h>
#ifdef T
#include <my_ppmptd/time/22/1.h>
#ifdef T
#include <my_ppmptd/time/22/2.h>
#ifdef T
#include <my_ppmptd/time/22/3.h>
#ifdef T
#include <my_ppmptd/time/22/4.h>
#ifdef T
#include <my_ppmptd/time/22/5.h>
#ifdef T
#include <my_ppmptd/time/22/6.h>
#ifdef T
#include <my_ppmptd/time/22/7.h>
#ifdef T
#include <my_ppmptd/time/22/8.h>
#ifdef T
#include <my_ppmptd/time/22/9.h>
#ifdef T
#include <my_ppmptd/time/22/10.h>
#ifdef T
#include <my_ppmptd/time/22/11.h>
#ifdef T
#include <my_ppmptd/time/22/12.h>
#ifdef T
#include <my_ppmptd/time/22/13.h>
#ifdef T
#include <my_ppmptd/time/22/14.h>
#ifdef T
#include <my_ppmptd/time/22/15.h>
#ifdef T
#include <my_ppmptd/time/22/16.h>
#ifdef T
#include <my_ppmptd/time/22/17.h>
#ifdef T
#include <my_ppmptd/time/22/18.h>
#ifdef T
#include <my_ppmptd/time/22/19.h>
#ifdef T
#include <my_ppmptd/time/22/20.h>
#ifdef T
#include <my_ppmptd/time/22/21.h>
#ifdef T
#include <my_ppmptd/time/22/22.h>
#ifdef T
#include <my_ppmptd/time/22/23.h>
#ifdef T
#include <my_ppmptd/time/22/24.h>
#ifdef T
#include <my_ppmptd/time/22/25.h>
#ifdef T
#include <my_ppmptd/time/22/26.h>
#ifdef T
#include <my_ppmptd/time/22/27.h>
#ifdef T
#include <my_ppmptd/time/22/28.h>
#ifdef T
#include <my_ppmptd/time/22/29.h>
#ifdef T
#include <my_ppmptd/time/22/30.h>
#ifdef T
#include <my_ppmptd/time/22/31.h>
#ifdef T
#include <my_ppmptd/time/22/32.h>
#ifdef T
#include <my_ppmptd/time/22/33.h>
#ifdef T
#include <my_ppmptd/time/22/34.h>
#ifdef T
#include <my_ppmptd/time/22/35.h>
#ifdef T
#include <my_ppmptd/time/22/36.h>
#ifdef T
#include <my_ppmptd/time/22/37.h>
#ifdef T
#include <my_ppmptd/time/22/38.h>
#ifdef T
#include <my_ppmptd/time/22/39.h>
#ifdef T
#include <my_ppmptd/time/22/40.h>
#ifdef T
#include <my_ppmptd/time/22/41.h>
#ifdef T
#include <my_ppmptd/time/22/42.h>
#ifdef T
#include <my_ppmptd/time/22/43.h>
#ifdef T
#include <my_ppmptd/time/22/44.h>
#ifdef T
#include <my_ppmptd/time/22/45.h>
#ifdef T
#include <my_ppmptd/time/22/46.h>
#ifdef T
#include <my_ppmptd/time/22/47.h>
#ifdef T
#include <my_ppmptd/time/22/48.h>
#ifdef T
#include <my_ppmptd/time/22/49.h>
#ifdef T
#include <my_ppmptd/time/22/50.h>
#ifdef T
#include <my_ppmptd/time/22/51.h>
#ifdef T
#include <my_ppmptd/time/22/52.h>
#ifdef T
#include <my_ppmptd/time/22/53.h>
#ifdef T
#include <my_ppmptd/time/22/54.h>
#ifdef T
#include <my_ppmptd/time/22/55.h>
#ifdef T
#include <my_ppmptd/time/22/56.h>
#ifdef T
#include <my_ppmptd/time/22/57.h>
#ifdef T
#include <my_ppmptd/time/22/58.h>
#ifdef T
#include <my_ppmptd/time/22/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifdef T
#include <my_ppmptd/time/23/0.h>
#ifdef T
#include <my_ppmptd/time/23/1.h>
#ifdef T
#include <my_ppmptd/time/23/2.h>
#ifdef T
#include <my_ppmptd/time/23/3.h>
#ifdef T
#include <my_ppmptd/time/23/4.h>
#ifdef T
#include <my_ppmptd/time/23/5.h>
#ifdef T
#include <my_ppmptd/time/23/6.h>
#ifdef T
#include <my_ppmptd/time/23/7.h>
#ifdef T
#include <my_ppmptd/time/23/8.h>
#ifdef T
#include <my_ppmptd/time/23/9.h>
#ifdef T
#include <my_ppmptd/time/23/10.h>
#ifdef T
#include <my_ppmptd/time/23/11.h>
#ifdef T
#include <my_ppmptd/time/23/12.h>
#ifdef T
#include <my_ppmptd/time/23/13.h>
#ifdef T
#include <my_ppmptd/time/23/14.h>
#ifdef T
#include <my_ppmptd/time/23/15.h>
#ifdef T
#include <my_ppmptd/time/23/16.h>
#ifdef T
#include <my_ppmptd/time/23/17.h>
#ifdef T
#include <my_ppmptd/time/23/18.h>
#ifdef T
#include <my_ppmptd/time/23/19.h>
#ifdef T
#include <my_ppmptd/time/23/20.h>
#ifdef T
#include <my_ppmptd/time/23/21.h>
#ifdef T
#include <my_ppmptd/time/23/22.h>
#ifdef T
#include <my_ppmptd/time/23/23.h>
#ifdef T
#include <my_ppmptd/time/23/24.h>
#ifdef T
#include <my_ppmptd/time/23/25.h>
#ifdef T
#include <my_ppmptd/time/23/26.h>
#ifdef T
#include <my_ppmptd/time/23/27.h>
#ifdef T
#include <my_ppmptd/time/23/28.h>
#ifdef T
#include <my_ppmptd/time/23/29.h>
#ifdef T
#include <my_ppmptd/time/23/30.h>
#ifdef T
#include <my_ppmptd/time/23/31.h>
#ifdef T
#include <my_ppmptd/time/23/32.h>
#ifdef T
#include <my_ppmptd/time/23/33.h>
#ifdef T
#include <my_ppmptd/time/23/34.h>
#ifdef T
#include <my_ppmptd/time/23/35.h>
#ifdef T
#include <my_ppmptd/time/23/36.h>
#ifdef T
#include <my_ppmptd/time/23/37.h>
#ifdef T
#include <my_ppmptd/time/23/38.h>
#ifdef T
#include <my_ppmptd/time/23/39.h>
#ifdef T
#include <my_ppmptd/time/23/40.h>
#ifdef T
#include <my_ppmptd/time/23/41.h>
#ifdef T
#include <my_ppmptd/time/23/42.h>
#ifdef T
#include <my_ppmptd/time/23/43.h>
#ifdef T
#include <my_ppmptd/time/23/44.h>
#ifdef T
#include <my_ppmptd/time/23/45.h>
#ifdef T
#include <my_ppmptd/time/23/46.h>
#ifdef T
#include <my_ppmptd/time/23/47.h>
#ifdef T
#include <my_ppmptd/time/23/48.h>
#ifdef T
#include <my_ppmptd/time/23/49.h>
#ifdef T
#include <my_ppmptd/time/23/50.h>
#ifdef T
#include <my_ppmptd/time/23/51.h>
#ifdef T
#include <my_ppmptd/time/23/52.h>
#ifdef T
#include <my_ppmptd/time/23/53.h>
#ifdef T
#include <my_ppmptd/time/23/54.h>
#ifdef T
#include <my_ppmptd/time/23/55.h>
#ifdef T
#include <my_ppmptd/time/23/56.h>
#ifdef T
#include <my_ppmptd/time/23/57.h>
#ifdef T
#include <my_ppmptd/time/23/58.h>
#ifdef T
#include <my_ppmptd/time/23/59.h>
#else
#define MY_PPMPTD_TIME_HOURS Error_couldnt_match_time
#define MY_PPMPTD_TIME_MINUTES Error_couldnt_match_time
#define MY_PPMPTD_TIME_SECONDS Error_couldnt_match_time
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#pragma pop_macro ("T")
