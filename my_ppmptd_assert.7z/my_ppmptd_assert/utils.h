#pragma once

#define MY_PPMPTD_PCAT(a,b) a##b
#define MY_PPMPTD_GCC_ASSERT(p,a...) MY_PPMPTD_PCAT(%,:) p (a)
